const express = require("express")
const app = express()
const cookieParser = require('cookie-parser') 
require("dotenv").config({ path: "./config.env" })
const morgan = require("morgan")
const fs = require("fs")
const xss = require("xss-clean")
const helmet = require("helmet")
const port = process.env.PORT || 4000
const mysql = require("mysql")

process.on("uncaughtException", (err) => {
  console.log("uncaughtException Error... System will terminate soon")

  console.log(err.name, err.message, err.stack)

  process.exit(1)
})

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password : "1234@1234",
  database: "pokemon",
  multipleStatements: true,
})

app.set("view engine", "ejs")
app.use(express.static("public"))


app.use(helmet())
app.use(express.json({ limit: "10MB" }))
app.use(cookieParser())
app.use(morgan("dev"))
app.use(xss())

// routes will be here
app.get("/", async (req, res) => {
     
//get all pokemons
   db.query("SELECT * FROM exam_monsters;" , ((err, result) => {
    if (err) {
      throw err
    } else {
        res.render("pages/Home", {pokemons : result})

    }
  }) )

})

app.get("/list", (req, res) => {
  res.render("pages/List")
})

app.get("/quiz", (req, res) => {
  res.render("pages/Quiz")
})

app.get("/update", (req, res) => {
  res.render("pages/Update")
})

app.post("/list", (req, res) => {
  const elementName = ["Fire","Electric","Water","Gas","Normal"]
  console.log(req.body)
    res.render("pages/List")
})

app.all("*", (req, res) => {
  res.writeHead(301, {
    Location: "http://" + req.headers["host"] + "/report",
  })
  return res.end()

})

// server
app.listen(port, async () => {
  db.connect((err) => {
    if (err) {
      throw err
    }
    console.log("DB connected")
    
  })

  const pokemons = fs.readFileSync('./pokemon.sql').toString();
     await db.query(pokemons, (err, result) => {
      if (err) {
        throw err
      }
      console.log("query completed")
    })
    console.log(`Server is running on port ${port}`)
})


process.on("unhandledRejection", (err) => {
  console.log("unhandledRejection Error... System will terminate soon")
  console.log(err.name, err.message, err.stack)
  server.close(() => {
    process.exit(1)
  })
})