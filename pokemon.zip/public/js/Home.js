// const title = document.getElementsByClassName("title")[0]

// const something = () => {
//   console.log("function called")
// }
// title.addEventListener("click", something)


// console.log("hlw from the report page")